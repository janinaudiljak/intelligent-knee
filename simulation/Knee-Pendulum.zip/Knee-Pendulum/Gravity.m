
function g_0 = Gravity(theta_hip)   
 % Gravity - Calculate the gravity vector in the hip frame.
%GRAVITY Summary of this function goes here
%   theta_hip - Angle of the hip joint in radians.

g = 9.82;
g_ch = [0; 0; g];     % Gravity vector in the chest frame (assuming vertical)

 % Assuming the hip rotates about the Z-axis, the rotation matrix from the chest frame to the hip frame would be:
r_ch_hip = [cos(theta_hip) -sin(theta_hip) 0; 
    sin(theta_hip) cos(theta_hip) 0; 
    0 0 1];                     % 2D Rotation Matrix about Z-axis

% Gravity vector in the hip frame
g_hip = r_ch_hip * g_ch;

% Since the hip is supposed to be still, we can assume a static transformation
% since there's no rotation from hip to knee
% from the hip to the base (0) frame.
r_hip_0 = eye(3);     % basicly the identity matrix   %TODO  something:func_rotation_theta_hip

% Transform the gravity vector to the base (0) frame
g_0 = r_hip_0*g_hip;     %   g_0 - Gravity vector in the hip reference frame.

end



