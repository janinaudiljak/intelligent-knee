
function Q = Trajectory_generator(u)
    %   qi: initial position
    %   qf: final position
    %   totalTime: the total time to move from qi to qf
    %   t0: the current simulation time
    qi = u(1);
    qf = u(2);
    tfin = u(3);
    t0 = u(4);

    a0 = qi;
    a1 = 0;
    a2 = (3/(tfin^2)) * (qf - qi);
    a3 = (-2/(tfin^3)) * (qf - qi);
    
    % Calculate position, velocity, and acceleration. Lecture 7 slide 6
    qd = a0 + a1*t0 + a2*t0^2 + a3*t0^3;
    qdp = a1 + 2*a2*t0 + 3*a3*t0^2; % Velocity
    qddp = 2*a2 + 6*a3*t0; % Acceleration
    
   Q = [qd, qdp];
end




