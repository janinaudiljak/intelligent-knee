function Tau_f = Tau_f(u)
%  define q1 based on your input Q

F_ef= u(1);
Wf = u(2);
Q = u(3);
l1= u(4);
l2 = u(5);
l3 = u(6);


F_ef = [0; 1; 0]; % 3x1 vector for external force
Wf = 1;       
q1 = Q;

    %Calculate Rotation matrix R0_ef
    R0_1 = [cos(q1) -sin(q1) 0;
            sin(q1)  cos(q1) 0 ;
             0        0       1];

  R1_ef = eye(3); % 3x3 Identity matrix

   R0_ef = R0_1 * R1_ef; % 0 to end-effector frame

  % Calculate the partial derivative of the forward kinematics with respect to q1
   J0_ef = [-l2*sin(q1) - l3*sin(q1);
                l2*cos(q1) + l3*cos(q1);
                         0          ];              


F0 = R0_ef * F_ef; %
  
Tau = J0_ef' * F0;  % slide 47 lec7. J0_ef is based on q1 in its own function.
Tau_f= Tau * Wf;
   

end
   
