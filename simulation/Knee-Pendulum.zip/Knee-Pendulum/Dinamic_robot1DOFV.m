
function Qpp = Dinamic_robot1DOFV(u)
%DINAMIC_ROBOT1DOFV Dynamic model of a 1 DOF robot (Pendulum)
%   u: vector of input arguments (defined by the simulink model)

%Joint Position
q1=u(1);

%Joint Velocity
qp1=u(2);

%Kinematic Parameters
l1=u(3);    %length upper leg
l2=u(4);    %lenght lower leg
l3=u(14);   %endeffector of orthosis
cm1=u(17); %center of mass of leg
cm2=u(18); %center of mass orthosis

%Dynamic Parameters
m1=u(5);   %mass of leg
m2=u(15);  % mass of orthosis

% Inertia
Inertia1=u(6);   % inertia of leg
Inertia2=u(16);     % inertia of orthosis

%Viscous Friction Matrix
Beta(1,1)=u(9);

%Direction of the Gravity Vector
g_0 = u(12);

%Joint Position Vector
Q=q1;

%Joint Velocity Vector
Qp=qp1;
g = u(7);

%Inertia Matrix
M(1,1) = (Inertia1 + cm1^2 * m1) + (Inertia2 + cm2^2 * m2);
%The terms cm1^2 * m1 and cm2^2 * m2 represent the additional moments of inertia due to the mass of each component 
% being a distance cm1 or cm2 from the axis of rotation, according to the parallel axis theorem.

%Gravitational Torques Vector
G(1,1)=(cm1*m1*(g_0*cos(q1) - g_0*sin(q1))) + (cm2*m2*(g_0*cos(q1) - g_0*sin(q1)));

Tau_total=u(12);

% Direct dynamic model     
Qpp=(M)\(Tau_total-G-Beta*Qp);     

end 




