
function Tau_k = Tau_k(u)
    % TAU PD control for a 1 DOF robot (Pendulum)

q1 =u(1); 
qp1 = u(2); 
Kp = u(3); 
Kd = u(4); 
qd = u(5);
qdp = u(6);
Wk = u(7);

    % Regulation then zero (assuming desired velocity qdp is zero)
    % Joint position error
    dq = qd - q1;

    dqp = qdp - qp1;

    % PD controller
    Tau = Kp * dq + Kd * dqp;
    Tauk = Tau*Wk;

    Tau_k =  [Tauk; dq]; % Concatenate Tau and dq to form a 2-element vector
  
end


