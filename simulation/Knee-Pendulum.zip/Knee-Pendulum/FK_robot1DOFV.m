
function X= FK_robot1DOFV(u)
% Forward kinematics for a leg with a single knee joint
%   q1: Joint angle at the knee
%  theta_hip: joint angle at the hip
%   l1: Length of the upper leg (hip to knee)
%   l2: Length of the lower leg (knee to ankle)
%   l3: offset

q1 = u(1);  
l1 = u(2); 
l2 = u(3); 
theta_hip = u(4);
l3 = u(5);

% Transformation from the world to the hip(w) to knee(0), As it hip is the 
% world frame and the knee (0) frame
T_w_0 = [cos(theta_hip) sin(theta_hip) 0  l1*cos(theta_hip);
         -sin(theta_hip)  cos(theta_hip) 0  -l1*sin(theta_hip);
         0        0       1  0;
         0        0       0  1];

% Transformation from the world to the hip(w) to knee(0)
%rotation in z-axis
 T_0_1 = [cos(q1) -sin(q1) 0  l2*cos(q1);
         sin(q1)  cos(q1) 0  l2*sin(q1);
         0        0       1  0;
         0        0       0  1];

% Transformation from the ankle to the end effector
    T_1_e = [1 0 0 0;
             0 1 0 l3;
             0 0 1 0;
             0 0 0 1];

    % Overall transformation from world to end effector
    T_w_e = T_w_0 * T_0_1 * T_1_e;

X = T_w_e(1:3, 4);

end




