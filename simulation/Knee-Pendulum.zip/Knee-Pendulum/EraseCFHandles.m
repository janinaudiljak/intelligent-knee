
function EraseCFHandles( handles )
%ERASECFCFHANDLES Deletes all the objects in the list of handles, except
%the figure handle and the main workspace handle
%   handles: list of object handles

sH=size(handles);


% In case the handles are arranged as row vector or column vector
if sH(1)>=sH(2)
    nHandles=sH(1);
else
    nHandles=sH(2);
end

for i=1:nHandles
    % if the handle exist and it is not root, nor figure, nor axes, then
    % delete it
    % find type
    %Firs check if is handle to avoid the problem of graph object
    if (ishandle(handles(i)))
        type=handles(i).Type;    
        if (~strcmp(type,'root'))&&(~strcmp(type,'figure'))&&(~strcmp(type,'axes'))
            %         fprintf(1,"(%d) Type %s Deleted!",i,type);
            delete(handles(i));
        end
    end
end

end


